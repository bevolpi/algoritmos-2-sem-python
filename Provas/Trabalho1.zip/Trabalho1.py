a =  int(input(""))

for i in range (a):
    a = input("")
    frase = ""
    for i in a:
        if(ord(i)==32):
            aux= ord(i)
        elif(ord(i)>96 and ord(i)<122 or ord(i)>64 and ord(i)<=90):
            aux = ord(i)+3
        else:
            aux = ord(i)
        frase=frase+ chr(aux)

    frase = str(frase[::-1])
    novafrase = ""

    for i in range (len(a)):
        if(ord(frase[i]) == 32):
            aux= ord(frase[i])
        elif(i>=int(len(a)/2)):
            aux = ord(frase[i])-1
        else:
            aux = ord(frase[i])
        novafrase = novafrase+ chr(aux)
    print(novafrase)